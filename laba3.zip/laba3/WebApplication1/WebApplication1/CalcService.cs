﻿namespace WebApplication1
{
    public class CalcService
    {
        public int Add(int x, int y) => x + y;
        public int Sub(int x, int y) => x - y;
        public int Multi(int x, int y) => x * y;
        public int Div(int x, int y) => x / y;

    }

}
