﻿using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace ConfigurationApp
{
    public class CompanyService
    {
        private IConfiguration _configuration;

        public CompanyService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GetCompanyWithMostEmployees()
        {
            var companies = GetCompaniesWithEmployees();
            int maxEmployees = 0;
            string companyWithMostEmployees = "";

            foreach (var company in companies)
            {
                if (company.Value > maxEmployees)
                {
                    maxEmployees = company.Value;
                    companyWithMostEmployees = company.Key;
                }
            }

            return companyWithMostEmployees;
        }

        public Dictionary<string, int> GetCompaniesWithEmployees()
        {
            var companies = new Dictionary<string, int>();

            var companiesSection = _configuration.GetSection("Companies");
            foreach (var company in companiesSection.GetChildren())
            {
                var companyName = company.GetValue<string>("companyName");
                var employeesCount = company.GetValue<int>("employeesCount");
                companies.Add(companyName, employeesCount);
            }

            return companies;
        }
    }
}
