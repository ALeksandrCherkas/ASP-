﻿namespace WebApplication1
{
    public class Person
    {
        public String Name { get; set; }
        public int Age { get; set; }
        public String Country { get; set; }
        public String University { get; set; }
        public Person(string name, int age, string status, string country, string university)
        {
            Name = name;
            Age = age;
            Country = country;
            University = university;
        }

        public Person()
        {
            Name = "";
            Age = 0;
            Country = "";
            University = "";
        }
        public override string ToString()
        {
            return $"Name: {Name}\nAge: {Age}\nCountry: {Country}\nUniversity: {University}";
        }
    }
}
