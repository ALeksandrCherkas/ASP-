﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace ConfigurationApp
{
    public class Startup
    {
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSingleton<CompanyService>();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.Run(async (context) =>
            {
                var companyService = context.RequestServices.GetService<CompanyService>();
                var companyWithMostEmployees = companyService.GetCompanyWithMostEmployees();

                await context.Response.WriteAsync($"Company with most employees: {companyWithMostEmployees}");
            });
        }
    }
}
