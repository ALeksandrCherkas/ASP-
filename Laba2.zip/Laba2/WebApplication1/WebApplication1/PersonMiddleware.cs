﻿using Microsoft.Extensions.Options;
using System;

namespace WebApplication1
{
    public class PersonMiddleware
    {
        readonly RequestDelegate next;

        public Person Person { get; }

        public PersonMiddleware(RequestDelegate next, IOptions<Person> options)
        {
            this.next = next;
            Person = options.Value;
        }
        public async Task InvokeAsync(HttpContext context)
        {
            if (context.Request.Path == "/")
            {
                await context.Response.WriteAsync(Person.ToString());
            }
            else
            {
                await next(context);
            }
        }
    }
}
