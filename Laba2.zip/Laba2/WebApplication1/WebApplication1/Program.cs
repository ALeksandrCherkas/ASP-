using System.Text;
using WebApplication1;
using Microsoft.Extensions.Options;
using System;
using WebApplication1;

var builder = WebApplication.CreateBuilder(args);

builder.Configuration.AddIniFile("companyInfo.ini");

builder.Services.Configure<Person>(builder.Configuration);
builder.Configuration.AddJsonFile("myBio.json");

var app = builder.Build();

app.UseMiddleware<PersonMiddleware>();
app.Map("/companies", (IConfiguration appConfig) =>
{
    StringBuilder strBld = new();

    var microsoft = appConfig.GetSection("Microsoft").Get<Company>();
    var apple = appConfig.GetSection("Apple").Get<Company>();
    var google = appConfig.GetSection("Google").Get<Company>();

    List<Company> companyList = new() { apple, microsoft, google };

    Company maxEmployees = companyList[0];
    foreach (var company in companyList)
    {
        strBld.AppendLine($"Company Name: {company.CompanyName}, Employees Count: {company.EmployeesCount}");
        if (company.EmployeesCount > maxEmployees.EmployeesCount)
        {
            maxEmployees = company;
        }
    }
    strBld.AppendLine($" ");

    strBld.Append($"Better company with bigger number of employees: {maxEmployees.CompanyName}");
    return strBld.ToString();
}
);
app.MapGet("/", () => "Hello User!");
app.Run();
