﻿namespace WebApplication1
{
    public class Company
    {
        public String CompanyName { get; set; }
        public int EmployeesCount { get; set; }
        public Company()
        {
            CompanyName = "";
            EmployeesCount = 0;
        }
    }
}
