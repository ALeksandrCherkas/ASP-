using Laba1;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.UseMiddleware<ErrorHandlingMiddleware>();
app.UseMiddleware<AuthentificatonMiddleware>();
app.UseMiddleware<CompanyMiddleware>();
app.Run();

class Company
{
    String id;
    String name;
    int employeesCount;
    Random random = new Random();
    public Company() { }
    public Company(String id, String name)
    {
        this.id = id;
        this.name = name;
    }
    public Company(String id, String name, int employeescount)
    {
        this.id = id;
        this.name = name;
        this.employeesCount = employeescount;
    }
    public int EmployeesCount
    {
        get { return employeesCount; }
        set { employeesCount = value; }
    }
    public String Name
    {
        get { return name; }
        set { name = value; }
    }
}

