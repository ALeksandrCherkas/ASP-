﻿using System.Reflection;

namespace Laba1
{
    public class CompanyMiddleware
    {
        readonly RequestDelegate next;
        public CompanyMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            Random random = new Random();
            int randNumber = random.Next(0, 100);
            Company com1 = new Company("1", "Company", 21);

            var sitePath = context.Request.Path;
            var id = context.Request.Query["id"];

            var response = context.Response;
            response.ContentType = "text/html; charset=utf-8";

            if (sitePath == "/company" && (id == "1"))
            {
                await context.Response.WriteAsync($" <h2>Company: {com1.Name}, Employes Number: {com1.EmployeesCount}</h2>");
            }
            else if (sitePath == "/random")
            {
                await context.Response.WriteAsync($" <h2>Company: {com1.Name}, Employes Number: {randNumber}</h2>");
            }
            else
            {
                context.Response.StatusCode = 404;
            }
        }
    }

}
