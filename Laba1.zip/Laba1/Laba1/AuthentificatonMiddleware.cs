﻿namespace Laba1
{
    public class AuthentificatonMiddleware
    {
        readonly RequestDelegate next;

        public AuthentificatonMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var token = context.Request.Query["token"];
            if (token == "admin" || token == "employee")
            {
                await next.Invoke(context);
            }
            else if (string.IsNullOrWhiteSpace(token))
            {
                context.Response.StatusCode = 404;
            }
            else
            {
                context.Response.StatusCode = 403;
            }
        }
    }

}
